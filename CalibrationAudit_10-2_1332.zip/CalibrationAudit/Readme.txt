Calibration Audit Example

Overview: 
Obtains calibration information for the hardware on a selected target. The target can be left empty for localhost.

Requirements: 
NI System Configuration, applicable device drivers

Instructions:
1. Enter the Target. Enter the User Name and Password if necessary.
2. Click "Run Audit".